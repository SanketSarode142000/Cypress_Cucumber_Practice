import { Given, When, Then, And } from "cypress-cucumber-preprocessor/steps";

Given('Open the browser and paste the url', () => {
    cy.visit('https://v1.training-support.net/selenium/simple-form');
});

When('User should enter all the valid details', () => {
    cy.xpath('//input[@placeholder="First Name"]').type('john');
    cy.xpath('//input[@placeholder="Last Name"]').type('doe');
    cy.xpath('//input[@placeholder="abc@xyz.com"]').type('john.doe@gmail.com');
    cy.xpath('//input[@placeholder="9876543210"]').type('7888054055');
})

And('User click on submit button', () => {
    cy.xpath('//input[@class="ui green button"]').click();
})

Then ('User should able to login successfully with valid credentials', () => {
    cy.xpath('//input[@class="ui button"]').click();
})